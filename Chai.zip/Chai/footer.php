<footer>
      <p>Тут вы можете поддержать бедного создателя сайта ¡_¡</p>
      <div class="Donate-button">
        <button>Отправить</button>
      </div>
    </footer>
  </body>
  </html>
