<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?> - <?php is_front_page() ? bloginfo('description') : wp_title(''); ?></title>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
</head>
<body>
  <header>
    <img src="http://gg/wp-content/uploads/2024/12/header-image.jpg"
    <div class="header-text">
      <h1>Плюсы видов приготовления чая</h1>
      <p>Разное заваривание чая приносит абсолютно разные эффекты! И на этом сайте я покажу вам некоторые плюсы видов приготовления чая</p>
    </div>
  </header>

  <nav>
    <a href="#">Информация про пакетики</a>
    <a href="#">Информация про заварку</a>
    <a href="#">Врачебные рекомендации</a>
    <a href="#">Другие мои сайты</a>
  </nav>
