<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Страница не найдена</title>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
  <style>
    .not-found {
      text-align: center;
      padding: 50px;
    }
    .not-found h1 {
      font-size: 100px;
      margin: 0;
    }
    .not-found p {
      font-size: 20px;
    }
    .not-found a {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #f4a442;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    .not-found a:hover {
      background-color: #d37c1f;
    }
  </style>
</head>
<body>
  <div class="not-found">
    <h1>404</h1>
    <p>Извините, страница не найдена!</p>
    <p>Похоже, эта страница пропала в чайной туманности.</p>
    <a href="<?php echo home_url(); ?>">Вернуться на главную</a>
  </div>
</body>
</html>
